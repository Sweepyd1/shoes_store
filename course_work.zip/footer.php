    </main>
    <footer class="bg-light text-center text-muted py-4">
        <p>&copy; 2025 Магазин Обуви. Все права защищены.</p>
        <p><a href="#">Политика конфиденциальности</a> | <a href="#">Условия использования</a></p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/script.js"></script>
</body>
</html>